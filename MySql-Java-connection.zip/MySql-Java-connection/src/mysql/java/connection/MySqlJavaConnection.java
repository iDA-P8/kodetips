/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysql.java.connection;

/**
 *
 * @author alexa
 */

import java.sql.*;

public class MySqlJavaConnection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String forName = "com.mysql.cj.jdbc.Driver";
        try {
            Class.forName(forName);
            System.out.println("Driver Loaded Successfully");
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver Failed To Load Successfully");
            System.out.println(ex.getMessage());
        }
        
        
try{  
    // Get the class in the projects library. Under Extensions in the Java folder on this computer.
Class.forName("com.mysql.cj.jdbc.Driver");
    // Open the connection using a string
Connection con=DriverManager.getConnection(  
        // Connect using localhost, to db: gregs_list, and define the timezone (otherwise you will get an error)
    "jdbc:mysql://localhost/gregs_list?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC"
        // User: root, password: password
    ,"root","password");  

Statement stmt=con.createStatement(); 
ResultSet rs=stmt.executeQuery("SELECT * FROM girls");  // Run the query and save the result in a ResultSet

while(rs.next()) { // Next row in the Result Set
    // Get the values in the three columns on the current row.
System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)); 
}

con.close(); // Close the connection 

}catch(Exception e){ System.out.println(e);}  
        
        
        
        
    }
        
        
    }
    

